﻿using Microsoft.Practices.ServiceLocation;
using SW.Ecommerce.Domain.Interfaces;
using SW.Ecommerce.Infrastructure.Repositorio.EF;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

namespace SW.Ecommerce.Infrastructure.Repositorio
{
    public class RepositorioBase<TEntity> : IRepositorioBase<TEntity> where TEntity : class
    {
        protected DbContext Context { get; private set; }

        public RepositorioBase()
        {
            var contextManager = ServiceLocator.Current.GetInstance<ContextManager>();

            Context = contextManager.Context;
        }

        public void Alterar(TEntity obj)
        {
            Context.Entry(obj).State = EntityState.Modified;
        }

        public void Excluir(TEntity obj)
        {
            Context.Set<TEntity>().Remove(obj);
        }

        public void Excluir(int id)
        {
            var obj = Obter(id);
            Excluir(obj);
        }

        public void Incluir(TEntity obj)
        {
            Context.Set<TEntity>().Add(obj);
        }

        public IEnumerable<TEntity> Obter()
        {
            return Context.Set<TEntity>().ToList();
        }

        public TEntity Obter(int id)
        {
            return Context.Set<TEntity>().Find(id);
        }
    }
}
