﻿using SW.Ecommerce.Domain.Entities;
using SW.Ecommerce.Domain.Interfaces;
using System.Collections.Generic;
using System.Linq;

namespace SW.Ecommerce.Infrastructure.Repositorio
{
    public class ProdutoRepositorio : RepositorioBase<Produto>, IProdutoRepositorio
    {
        public IEnumerable<Produto> ObterPelaPromocao(int id)
        {
            return Context.Set<Produto>().Where(p => p.PromocaoId == id).ToList();
        }
    }
}
