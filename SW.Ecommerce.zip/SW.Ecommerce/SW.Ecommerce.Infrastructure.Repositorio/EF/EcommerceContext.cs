﻿using SW.Ecommerce.Domain.Entities;
using System.Data.Entity;

namespace SW.Ecommerce.Infrastructure.Repositorio.EF
{
    public class EcommerceContext : DbContext
    {
        public DbSet<Produto> Produtos { get; set; }
        public DbSet<Promocao> Promocoes { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add(new ProdutoMap());
            modelBuilder.Configurations.Add(new PromocaoMap());
            modelBuilder.Configurations.Add(new CarrinhoMap());
        }
    }
}
