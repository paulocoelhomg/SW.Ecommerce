﻿using SW.Ecommerce.Domain.Entities;
using System.Data.Entity.ModelConfiguration;

namespace SW.Ecommerce.Infrastructure.Repositorio.EF
{
    public class CarrinhoMap : EntityTypeConfiguration<Carrinho>
    {
        public CarrinhoMap()
        {
            Property(p => p.Quantidade).IsRequired().HasColumnType("int");
            Property(p => p.ValorTotal).IsRequired().HasPrecision(10, 2);
        }
    }
}
