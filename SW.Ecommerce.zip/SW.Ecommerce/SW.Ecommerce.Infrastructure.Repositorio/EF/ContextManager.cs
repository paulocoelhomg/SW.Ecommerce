﻿using System.Data.Entity;
using System.Web;

namespace SW.Ecommerce.Infrastructure.Repositorio.EF
{
    public class ContextManager
    {
        private const string ContextKey = "ContextManager.Context";

        public DbContext Context
        {
            get
            {
                if (HttpContext.Current.Items[ContextKey] == null)
                {
                    HttpContext.Current.Items[ContextKey] = new EcommerceContext();
                }

                return (EcommerceContext)HttpContext.Current.Items[ContextKey];
            }
        }
    }
}
