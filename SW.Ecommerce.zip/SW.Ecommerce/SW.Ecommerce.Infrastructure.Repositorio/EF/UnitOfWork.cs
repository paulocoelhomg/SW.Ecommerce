﻿using Microsoft.Practices.ServiceLocation;
using SW.Ecommerce.Domain.Interfaces;
using System.Data.Entity;

namespace SW.Ecommerce.Infrastructure.Repositorio.EF
{
    public class UnitOfWork : IUnitOfWork
    {
        private DbContext _context;

        public void BeginTransaction()
        {
            var contextManager = ServiceLocator.Current.GetInstance<ContextManager>();
            _context = contextManager.Context;
        }

        public void Commit()
        {
            _context.SaveChanges();
        }
    }
}
