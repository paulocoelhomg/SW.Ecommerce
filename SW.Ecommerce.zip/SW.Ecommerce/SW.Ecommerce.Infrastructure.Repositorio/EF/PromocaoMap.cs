﻿using SW.Ecommerce.Domain.Entities;
using System.Data.Entity.ModelConfiguration;

namespace SW.Ecommerce.Infrastructure.Repositorio.EF
{
    public class PromocaoMap : EntityTypeConfiguration<Promocao>
    {
        public PromocaoMap()
        {
            Property(p => p.Nome).IsRequired().HasMaxLength(50);
            Property(p => p.TipoPromocao).IsRequired().HasColumnType("int");
            Property(p => p.QuantidadeNecessaria).IsRequired().HasColumnType("int");
            Property(p => p.QuantidadeBonus).IsRequired().HasColumnType("int");
            Property(p => p.ValorBonus).IsRequired().HasPrecision(10, 2);
        }
    }
}
