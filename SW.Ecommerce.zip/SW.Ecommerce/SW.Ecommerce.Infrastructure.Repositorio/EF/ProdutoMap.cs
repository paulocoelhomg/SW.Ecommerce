﻿using SW.Ecommerce.Domain.Entities;
using System.Data.Entity.ModelConfiguration;

namespace SW.Ecommerce.Infrastructure.Repositorio.EF
{
    public class ProdutoMap : EntityTypeConfiguration<Produto>
    {
        public ProdutoMap()
        {
            Property(p => p.Nome).IsRequired().HasMaxLength(50);
            Property(p => p.Preco).IsRequired().HasPrecision(10, 2);
        }
    }
}
