﻿using SW.Ecommerce.Domain.Entities;
using SW.Ecommerce.Domain.Enum;
using SW.Ecommerce.Domain.Interfaces;

namespace SW.Ecommerce.Infrastructure.Repositorio
{
    public class CarrinhoRepositorio : RepositorioBase<Carrinho>, ICarrinhoRepositorio
    {
        public decimal CalcularValorTotal(Carrinho carrinho)
        {
            decimal retorno = (decimal)0.0;

            if (carrinho.Produto != null)
            {
                decimal valorTotal = carrinho.Produto.Preco * carrinho.Quantidade;

                if (carrinho.Produto.Promocao == null)
                    retorno = valorTotal;
                else
                {
                    int quantidadeDesconto = 0;
                    int quantidadeSemDesconto = 0;
                    decimal valorDesconto = (decimal)0.0;
                    decimal valorSemDesconto = (decimal)0.0;

                    if (carrinho.Produto.Promocao.TipoPromocao == TipoPromocaoEnum.Quantidade)
                    {
                        //Calcula-se o valor a ser abatido do valor total calculado
                        quantidadeDesconto = carrinho.Quantidade / (carrinho.Produto.Promocao.QuantidadeNecessaria + carrinho.Produto.Promocao.QuantidadeBonus);
                        valorDesconto = carrinho.Produto.Preco * quantidadeDesconto;
                        retorno = valorTotal - valorDesconto;
                    }
                    else
                    {
                        //Calculam-se o valor com desconto e o valor sem desconto e somam-se ambos
                        quantidadeDesconto = carrinho.Quantidade / carrinho.Produto.Promocao.QuantidadeNecessaria;
                        valorDesconto = carrinho.Produto.Promocao.ValorBonus * quantidadeDesconto;
                        quantidadeSemDesconto = carrinho.Quantidade % carrinho.Produto.Promocao.QuantidadeNecessaria;
                        valorSemDesconto = carrinho.Produto.Preco * quantidadeSemDesconto;
                        retorno = valorDesconto + valorSemDesconto;
                    }
                }
            }

            return retorno;
        }
    }
}
