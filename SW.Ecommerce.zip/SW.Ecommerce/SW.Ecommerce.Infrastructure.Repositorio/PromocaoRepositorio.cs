﻿using SW.Ecommerce.Domain.Entities;
using SW.Ecommerce.Domain.Enum;
using SW.Ecommerce.Domain.Interfaces;
using System.Collections.Generic;
using System.Linq;

namespace SW.Ecommerce.Infrastructure.Repositorio
{
    public class PromocaoRepositorio : RepositorioBase<Promocao>, IPromocaoRepositorio
    {
        public IEnumerable<Promocao> ObterPeloTipo(TipoPromocaoEnum tipo)
        {
            return Context.Set<Promocao>().Where(p => p.TipoPromocao == tipo).ToList();
        }
    }
}
