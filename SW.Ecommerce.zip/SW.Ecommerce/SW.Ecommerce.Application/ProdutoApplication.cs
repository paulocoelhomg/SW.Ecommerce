﻿using SW.Ecommerce.Domain.Entities;
using SW.Ecommerce.Domain.Interfaces;
using System.Collections.Generic;

namespace SW.Ecommerce.Application
{
    public class ProdutoApplication : ApplicationBase
    {
        private readonly IProdutoRepositorio _produtoRepositorio;

        public ProdutoApplication(IProdutoRepositorio produtoRepositorio)
        {
            _produtoRepositorio = produtoRepositorio;
        }

        public void Incluir(Produto produto)
        {
            BeginTransaction();

            _produtoRepositorio.Incluir(produto);

            Commit();
        }

        public void Alterar(Produto produto)
        {
            BeginTransaction();

            _produtoRepositorio.Alterar(produto);

            Commit();
        }

        public void Excluir(int id)
        {
            BeginTransaction();

            _produtoRepositorio.Excluir(id);

            Commit();
        }

        public void Excluir(Produto produto)
        {
            BeginTransaction();

            _produtoRepositorio.Excluir(produto);

            Commit();
        }

        public Produto Obter(int id)
        {
            return _produtoRepositorio.Obter(id);
        }

        public IEnumerable<Produto> Obter()
        {
            return _produtoRepositorio.Obter();
        }

        public IEnumerable<Produto> ObterPelaPromocao(int id)
        {
            return _produtoRepositorio.ObterPelaPromocao(id);
        }
    }
}
