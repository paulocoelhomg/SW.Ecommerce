﻿using SW.Ecommerce.Domain.Entities;
using SW.Ecommerce.Domain.Interfaces;
using System.Collections.Generic;

namespace SW.Ecommerce.Application
{
    public class CarrinhoApplication : ApplicationBase
    {
        private readonly ICarrinhoRepositorio _carrinhoRepositorio;
        private readonly IProdutoRepositorio _produtoRepositorio;

        public CarrinhoApplication(ICarrinhoRepositorio carrinhoRepositorio)
        {
            _carrinhoRepositorio = carrinhoRepositorio;
        }

        public CarrinhoApplication(ICarrinhoRepositorio carrinhoRepositorio, IProdutoRepositorio produtoRepositorio)
        {
            _carrinhoRepositorio = carrinhoRepositorio;
            _produtoRepositorio = produtoRepositorio;
        }

        public void Incluir(Carrinho carrinho)
        {
            BeginTransaction();

            Produto produto = null;
            if (carrinho.Produto == null)
            {
                produto = _produtoRepositorio.Obter(carrinho.ProdutoId);
                carrinho.Produto = produto;
            }
            
            decimal valorTotal = CalcularValorTotal(carrinho);
            carrinho.ValorTotal = valorTotal;

            _carrinhoRepositorio.Incluir(carrinho);

            Commit();
        }

        public void Alterar(Carrinho carrinho)
        {
            BeginTransaction();

            decimal valorTotal = CalcularValorTotal(carrinho);
            carrinho.ValorTotal = valorTotal;

            _carrinhoRepositorio.Alterar(carrinho);

            Commit();
        }

        public void Excluir(int id)
        {
            BeginTransaction();

            _carrinhoRepositorio.Excluir(id);

            Commit();
        }

        public void Excluir(Carrinho carrinho)
        {
            BeginTransaction();

            _carrinhoRepositorio.Excluir(carrinho);

            Commit();
        }

        public Carrinho Obter(int id)
        {
            return _carrinhoRepositorio.Obter(id);
        }

        public IEnumerable<Carrinho> Obter()
        {
            return _carrinhoRepositorio.Obter();
        }

        private decimal CalcularValorTotal(Carrinho carrinho)
        {
            return _carrinhoRepositorio.CalcularValorTotal(carrinho);
        }
    }
}
