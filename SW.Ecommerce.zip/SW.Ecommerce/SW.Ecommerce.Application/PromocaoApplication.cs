﻿using SW.Ecommerce.Domain.Entities;
using SW.Ecommerce.Domain.Enum;
using SW.Ecommerce.Domain.Interfaces;
using System.Collections.Generic;

namespace SW.Ecommerce.Application
{
    public class PromocaoApplication : ApplicationBase
    {
        private readonly IPromocaoRepositorio _promocaoRepositorio;

        public PromocaoApplication(IPromocaoRepositorio promocaoRepositorio)
        {
            _promocaoRepositorio = promocaoRepositorio;
        }

        public void Incluir(Promocao promocao)
        {
            BeginTransaction();

            _promocaoRepositorio.Incluir(promocao);

            Commit();
        }

        public void Alterar(Promocao promocao)
        {
            BeginTransaction();

            _promocaoRepositorio.Alterar(promocao);

            Commit();
        }

        public void Excluir(int id)
        {
            BeginTransaction();

            _promocaoRepositorio.Excluir(id);

            Commit();
        }

        public void Excluir(Promocao promocao)
        {
            BeginTransaction();

            _promocaoRepositorio.Excluir(promocao);

            Commit();
        }

        public Promocao Obter(int id)
        {
            return _promocaoRepositorio.Obter(id);
        }

        public IEnumerable<Promocao> Obter()
        {
            return _promocaoRepositorio.Obter();
        }

        public IEnumerable<Promocao> ObterPeloTipo(TipoPromocaoEnum tipo)
        {
            return _promocaoRepositorio.ObterPeloTipo(tipo);
        }
    }
}
