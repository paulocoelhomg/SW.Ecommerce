﻿using SW.Ecommerce.Application;
using SW.Ecommerce.Domain.Entities;
using System.Web.Mvc;

namespace SW.Ecommerce.UI.Controllers
{
    public class CarrinhoController : Controller
    {
        private readonly CarrinhoApplication _carrinhoApplication;

        public CarrinhoController(CarrinhoApplication carrinhoApplication)
        {
            _carrinhoApplication = carrinhoApplication;
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Carrinho Carrinho)
        {
            if (ModelState.IsValid)
            {
                _carrinhoApplication.Incluir(Carrinho);

                return RedirectToAction("index");
            }
            return View(Carrinho);
        }

        public ActionResult Delete(int id)
        {
            Carrinho Carrinho = _carrinhoApplication.Obter(id);

            return View(Carrinho);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirm(int id)
        {
            if (ModelState.IsValid)
            {
                _carrinhoApplication.Excluir(id);

                return RedirectToAction("index");
            }
            return View();
        }

        public ActionResult Index()
        {
            var Carrinhos = _carrinhoApplication.Obter();

            return View(Carrinhos);
        }
    }
}