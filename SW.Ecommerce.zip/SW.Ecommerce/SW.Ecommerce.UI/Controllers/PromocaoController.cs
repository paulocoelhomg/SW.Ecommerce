﻿using SW.Ecommerce.Application;
using SW.Ecommerce.Domain.Entities;
using System.Web.Mvc;

namespace SW.Ecommerce.UI.Controllers
{
    public class PromocaoController : Controller
    {
        private readonly PromocaoApplication _promocaoApplication;

        public PromocaoController(PromocaoApplication promocaoApplication)
        {
            _promocaoApplication = promocaoApplication;
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Promocao promocao)
        {
            if (ModelState.IsValid)
            {
                _promocaoApplication.Incluir(promocao);

                return RedirectToAction("index");
            }
            return View(promocao);
        }

        public ActionResult Edit(int id)
        {
            Promocao promocao = _promocaoApplication.Obter(id);

            return View(promocao);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Promocao promocao)
        {
            if (ModelState.IsValid)
            {
                _promocaoApplication.Alterar(promocao);

                return RedirectToAction("index");
            }
            return View(promocao);
        }

        public ActionResult Delete(int id)
        {
            Promocao promocao = _promocaoApplication.Obter(id);

            return View(promocao);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirm(int id)
        {
            if (ModelState.IsValid)
            {
                _promocaoApplication.Excluir(id);

                return RedirectToAction("index");
            }
            return View();
        }

        public ActionResult Index()
        {
            var promocoes = _promocaoApplication.Obter();

            return View(promocoes);
        }
    }
}