﻿using SW.Ecommerce.Application;
using SW.Ecommerce.Domain.Entities;
using System.Web.Mvc;

namespace SW.Ecommerce.UI.Controllers
{
    public class ProdutoController : Controller
    {
        private readonly ProdutoApplication _produtoApplication;

        public ProdutoController(ProdutoApplication produtoApplication)
        {
            _produtoApplication = produtoApplication;
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Produto produto)
        {
            if (ModelState.IsValid)
            {
                _produtoApplication.Incluir(produto);

                return RedirectToAction("index");
            }
            return View(produto);
        }

        public ActionResult Edit(int id)
        {
            Produto produto = _produtoApplication.Obter(id);

            return View(produto);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Produto produto)
        {
            if (ModelState.IsValid)
            {
                _produtoApplication.Alterar(produto);

                return RedirectToAction("index");
            }
            return View(produto);
        }

        public ActionResult Delete(int id)
        {
            Produto produto = _produtoApplication.Obter(id);

            return View(produto);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirm(int id)
        {
            if (ModelState.IsValid)
            {
                _produtoApplication.Excluir(id);

                return RedirectToAction("index");
            }
            return View();
        }

        public ActionResult Index()
        {
            var produtos = _produtoApplication.Obter();

            return View(produtos);
        }
    }
}