﻿using Ninject.Modules;
using SW.Ecommerce.Domain.Interfaces;
using SW.Ecommerce.Infrastructure.Repositorio;
using SW.Ecommerce.Infrastructure.Repositorio.EF;

namespace SW.Ecommerce.Infrastructure.IoC
{
    public class IoCModule : NinjectModule
    {
        public override void Load()
        {
            Bind(typeof(IRepositorioBase<>)).To(typeof(RepositorioBase<>));
            Bind<IProdutoRepositorio>().To<ProdutoRepositorio>();
            Bind<IPromocaoRepositorio>().To<PromocaoRepositorio>();
            Bind<IUnitOfWork>().To<UnitOfWork>();
            Bind<ICarrinhoRepositorio>().To<CarrinhoRepositorio>();
            Bind<ContextManager>().ToSelf();
        }
    }
}
