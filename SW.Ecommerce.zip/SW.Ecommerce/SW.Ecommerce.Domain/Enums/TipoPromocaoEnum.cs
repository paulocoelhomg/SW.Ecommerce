﻿namespace SW.Ecommerce.Domain.Enum
{
    public enum TipoPromocaoEnum
    {
        Quantidade = 1,
        Valor = 2
    }
}
