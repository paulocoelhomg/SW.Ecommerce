﻿using SW.Ecommerce.Domain.Entities;

namespace SW.Ecommerce.Domain.Interfaces
{
    public interface ICarrinhoRepositorio : IRepositorioBase<Carrinho>
    {
        decimal CalcularValorTotal(Carrinho carrinho);
    }
}
