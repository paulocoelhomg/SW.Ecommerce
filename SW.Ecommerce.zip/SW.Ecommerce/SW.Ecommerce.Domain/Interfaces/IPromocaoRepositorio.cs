﻿using SW.Ecommerce.Domain.Entities;
using SW.Ecommerce.Domain.Enum;
using System.Collections.Generic;

namespace SW.Ecommerce.Domain.Interfaces
{
    public interface IPromocaoRepositorio : IRepositorioBase<Promocao>
    {
        IEnumerable<Promocao> ObterPeloTipo(TipoPromocaoEnum tipo);
    }
}
