﻿using SW.Ecommerce.Domain.Entities;
using System.Collections.Generic;

namespace SW.Ecommerce.Domain.Interfaces
{
    public interface IProdutoRepositorio : IRepositorioBase<Produto>
    {
        IEnumerable<Produto> ObterPelaPromocao(int id);
    }
}
