﻿using System.Collections.Generic;

namespace SW.Ecommerce.Domain.Interfaces
{
    public interface IRepositorioBase<TEntity> where TEntity: class
    {
        void Incluir(TEntity obj);
        void Excluir(int id);
        void Excluir(TEntity obj);
        TEntity Obter(int id);
        IEnumerable<TEntity> Obter();
        void Alterar(TEntity obj);
    }
}
