﻿using SW.Ecommerce.Domain.Enum;
using System.Collections.Generic;

namespace SW.Ecommerce.Domain.Entities
{
    public class Promocao
    {
        public Promocao()
        {
            Produtos = new List<Produto>();
        }

        public int Id { get; set; }
        public string Nome { get; set; }
        public TipoPromocaoEnum TipoPromocao { get; set; }
        public int QuantidadeNecessaria { get; set; }
        public int QuantidadeBonus { get; set; }
        public decimal ValorBonus { get; set; }
        public virtual ICollection<Produto> Produtos { get; set; }
    }
}
