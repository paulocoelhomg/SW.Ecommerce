﻿namespace SW.Ecommerce.Domain.Entities
{
    public class Carrinho
    {
        public int Id { get; set; }
        public int Quantidade { get; set; }
        public decimal ValorTotal { get; set; }
        public int ProdutoId { get; set; }
        public virtual Produto Produto { get; set; }
    }
}
